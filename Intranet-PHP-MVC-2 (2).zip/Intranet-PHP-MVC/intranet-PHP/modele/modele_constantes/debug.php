<?php
$debug = true;
if($debug){
    echo "GET :: ";  print_r($_GET);  echo "<br>";
    echo "POST : "; print_r($_POST); echo "<br>";
}
?>