<?php
function getCopyright(){
    return "le prof";
}
?>