<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <title>BTS-blanc</title>
   <link rel="stylesheet" href="./views/public/css/style.css">
</head>

<body>
   <?php include_once("./views/include/header.php") ?>
   <?php include_once("./views/include/nav.php") ?>
   
   <main>
      <h2>Page 2</h2>
      <p>Lorem400 ipsum dolor sit amet consectetur adipisicing elit. Inventore error sunt adipisci, rem labore, corporis
         cumque nostrum esse aspernatur, quae aliquam rerum est quidem beatae sint obcaecati similique nesciunt
         assumenda architecto? Mollitia quae doloribus veritatis labore! Laudantium quidem aut delectus autem voluptatem
         quia, vero odit enim similique saepe. Alias rem expedita quod delectus quasi ipsum odio quisquam nostrum
         reiciendis quis. Non voluptate labore illo odit necessitatibus iusto, ut velit quaerat error minus tempora
         perferendis rem, aspernatur explicabo amet aperiam ab, deleniti fugit nostrum atque deserunt ullam aliquid quo
         quia! Minus pariatur optio iste animi, quae quidem odit molestias facilis magnam delectus sequi quisquam!
         Facilis numquam similique nobis cum reiciendis fuga quos ea, expedita aspernatur, laborum eveniet molestias
         pariatur nihil animi dolor dicta quidem ipsa maxime a, accusantium dolores excepturi. Amet maxime harum
         voluptatem, ab sit est facere consequuntur maiores autem vero ratione obcaecati eaque nihil enim soluta dicta
         quidem modi explicabo saepe architecto distinctio ipsam veniam laboriosam. Sequi velit quo nobis sunt quod
         perferendis obcaecati iure adipisci nemo similique, temporibus corporis nesciunt aperiam, eius consectetur amet
         ut. Quod amet, excepturi numquam libero nemo quasi est laboriosam voluptas quisquam nostrum rem suscipit quis
         sed dolores, rerum repellat adipisci reiciendis illum nam dolorum possimus dignissimos tempora et. Repellendus,
         pariatur eveniet modi esse, facilis possimus voluptatum facere iste cum numquam vero similique distinctio?
         Optio molestias quas a qui tenetur ex earum? Dignissimos, eum voluptatem libero est itaque saepe! Nostrum,
         nulla similique autem officia iure, cum magnam ipsum vel incidunt minus hic aperiam mollitia ducimus, aliquam
         perspiciatis nesciunt. Ipsam magni, id est debitis atque eos corrupti quo sint, rerum, reprehenderit adipisci a
         consequatur. Suscipit magnam voluptatibus dolore reiciendis, voluptate, aperiam rerum, consequatur fugit quas
         deserunt eum sint! Quae eveniet sunt odio dignissimos facilis earum necessitatibus officia debitis beatae,
         cupiditate quas temporibus ad omnis magnam nulla! Explicabo vitae atque ea eius nam voluptatibus nisi,
         quibusdam nostrum non officiis, totam cum, neque adipisci molestiae a eum minus accusamus quod repellendus
         minima unde dicta placeat magni. Impedit laborum possimus dolorem placeat quo voluptates, nam facere quibusdam
         provident quisquam! Quod nostrum incidunt sint, repellendus autem architecto blanditiis aliquid. At voluptate
         ex sit vero. Quod, assumenda omnis amet possimus illo dolor consequatur deserunt nihil ad maxime molestias ex
         accusamus voluptatibus dicta architecto exercitationem quas asperiores nam cupiditate consectetur dolorum
         placeat magni sunt corrupti? Ex voluptatibus tenetur, debitis quasi deserunt ipsum distinctio maxime enim
         dicta, nobis molestiae libero a ullam.</p>
   </main>
   
   <?php include_once("./views/include/footer.php") ?>
</body>

</html>