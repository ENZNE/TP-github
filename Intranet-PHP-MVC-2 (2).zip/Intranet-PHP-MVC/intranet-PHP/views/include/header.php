<header>
    <h1>Intranet Anthropocene - Climat - Transition écologique</h1>
    <p>
        Lorem20 ipsum, dolor sit amet consectetur adipisicing elit. Unde eius sed repellat natus animi ex aliquid ea dolorem explicabo praesentium.
    </p>
</header>