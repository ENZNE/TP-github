<!-- 
    il ne faut pas définir la variable $copyright à ce niveau
    ici on n'a que du HTML et des echos et/ou include PHP dans le HTML
    la variable $copyright est définie dans les pages principales 
-->
<footer>
    <ul>
        <li>bla10</li>
        <li>bla20</li>
    </ul>
    <ol>
        <li>bla11</li>
        <li>bla22</li>
    </ol>
    <p>Copyright <?php echo $copyright ?></p>
</footer>