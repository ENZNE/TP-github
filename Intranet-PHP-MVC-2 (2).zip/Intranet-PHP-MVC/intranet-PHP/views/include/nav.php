<nav>
    <ul>
        <li><a href="./ctrl_accueil.php">Accueil</a></li>
        <li><a href="./ctrl_page1.php">page1</a></li>
        <li><a href="./ctrl_page2.php">page2</a></li>
        <li><a href="./ctrl_page3.php">page3</a></li>
        <li><a href="./ctrl_films.php">films</a></li>
        <li><a href="./ctrl_api_json.php">api json</a></li>
        <li><a href="./ctrl_api_json_format.php" target="_blank">api json format</a></li>
    </ul>
</nav>